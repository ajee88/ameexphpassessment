	<?php
        define('DB_SERVER', 'localhost');
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', 'ameex');
	define('DB_DATABASE', 'ases');
        ?>
